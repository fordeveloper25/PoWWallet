package com.example.powwallet

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val powResult = findViewById<TextView>(R.id.pow_result)
        val powButton = findViewById<Button>(R.id.btn_pow)

        powButton.setOnClickListener {
            powResult.text = "Mining..."
            val nonce = computePoW("PoWWallet")
            powResult.text = "PoW Success! Nonce: $nonce"
        }
    }

    external fun computePoW(input: String): String

    companion object {
        init {
            System.loadLibrary("pow")
        }
    }
}
