package com.example.powwallet

class PoWEngine {
    fun computePoW(input: String): String {
        var nonce = 0
        while (true) {
            val hash = (input + nonce.toString()).hashCode()
            if (hash % 256 == 0) break // Condizione base per PoW
            nonce++
        }
        return "Nonce: $nonce"
    }
}
