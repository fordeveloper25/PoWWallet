#!/bin/bash

# Firma l’APK con la chiave di rilascio
jarsigner -verbose -keystore my-release-key.jks app-release.apk alias_name

# Caricamento su Google Play (tramite API di Google Play Console)
gplaycli upload app-release.apk --track production

# Caricamento su F-Droid
fdroid publish app-release.apk

# Distribuzione su IPFS
HASH=$(ipfs add -q app-release.apk | tail -n1)
echo "Distribuito su IPFS: ipfs.io/ipfs/$HASH"
